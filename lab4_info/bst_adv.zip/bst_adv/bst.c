#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "bst.h"

/* update node count during the tree rooted at 't' */
static 
void fix_n(bst_t *t){
	if (!t) return;
	t->n = 1 + (t->l ? t->l->n : 0) + (t->r ? t->r->n : 0);
}

/* Single left and right rotations: not exported */
static 
bst_t *bst_rot_r(bst_t *t){
	bst_t *x = t->l;
	t->l = x->r;
	x->r = t;
	fix_n(t);
	fix_n(x);
	return x;
}

static 
bst_t *bst_rot_l(bst_t *t){
	bst_t *x = t->r;
	t->r = x->l;
	x->l = t;
	fix_n(t);
	fix_n(x);
	return x;
}

/* shorthand to node creation */
static bst_t *bst_new_node(int e, bst_t *l, bst_t *r, int n){
	bst_t *t = (bst_t *)malloc(sizeof(bst_t));
	t->e = e;
	t->n = n;
	t->l = l;
	t->r = r;
	return t;
}

/* exported routines */
bst_t *bst_make_empty(bst_t *t){
	if (t != NULL){
		bst_make_empty(t->l);
		bst_make_empty(t->r);
		free(t);
	}
	return NULL;
}

bst_t *bst_find(bst_t *t, int x){
	if (t == NULL)
		return NULL;
	if (x < t->e) /* smaller: visit left subtree */
		return bst_find(t->l, x);
	if (x > t->e) /* larger: visit right subtree */
		return bst_find(t->r, x);
	return t; /* match */
}

/* Recursive implementation */
bst_t *bst_find_min(bst_t *t){
	if (t == NULL)
		return NULL;
	return (t->l == NULL ? t : bst_find_min(t->l));
}

/* Non-recursive implementation */
bst_t *bst_find_max(bst_t *t){
	if (t != NULL)
		for ( ; t->r != NULL; t = t->r) ;
	return t;
}

bst_t *bst_insert(bst_t *t, int x){
	if (t == NULL) /* create and add a one-node tree */
		return bst_new_node(x, NULL, NULL, 1);

	else if (x < t->e) /* add in left subtree */
		t->l = bst_insert(t->l, x);
	else if (x > t->e) /* add in right subtree */
		t->r = bst_insert(t->r, x);

	t->n++;
	return t; /* key x exists, do NOTHING */
}

bst_t *bst_insert_root(bst_t *t, int x){
	if (t == NULL)
		return bst_new_node(x, NULL, NULL, 1);

	if (x < t->e){
		t->l = bst_insert_root(t->l, x);
		t = bst_rot_r(t);
	}
	else if (x > t->e){
		t->r = bst_insert_root(t->r, x);
		t = bst_rot_l(t);
	}
	return t;
}

bst_t *bst_insert_rand(bst_t *t, int x){
	if (t == NULL) return bst_new_node(x, NULL, NULL, 1);
	if (rand() < RAND_MAX / (t->n + 1))
		return bst_insert_root(t, x);
	if (x < t->e)
		t->l = bst_insert_rand(t->l, x);
	else if (x > t->e)
		t->r = bst_insert_rand(t->r, x);
	t->n++;
	return t;
}

bst_t *bst_delete(bst_t *t, int x){
	if (t == NULL)
		perror("Key not found!\n");
	else if (x < t->e) /* go left */
		t->l = bst_delete(t->l, x);
	else if (x > t->e) /* go right */
		t->r = bst_delete(t->r, x);
	else { /* key matches */
		if (t->l && t->r){ /* 2 children */
			/* replace smallest in right subtree */
			t->e = bst_find_min(t->r)->e;
			t->r = bst_delete(t->r, t->e);
		}
		else { /* 1 child or no child */
			bst_t *tmp = t;
			t = !t->l ? t->r : (!t->r ? t->l : 0);
			free(tmp);
		}
	}
	return t;
}

bst_t *bst_partition(bst_t *t, int k){
	int n = t->l ? t->l->n : 0;
	if (n > k){
		t->l = bst_partition(t->l, k);
		t = bst_rot_r(t);
	}
	if (n < k){
		t->r = bst_partition(t->r, k - n - 1);
		t = bst_rot_l(t);
	}
	return t;
}

bst_t *bst_balance(bst_t *t){
	if (t == NULL || t->n < 2) return t;
	t = bst_partition(t, t->n / 2);
	t->l = bst_balance(t->l);
	t->r = bst_balance(t->r);
	return t;
}

/* connect 'a' to the left subtree of 'b' by partitioning all nodes in
 * 'b' to its right subtree */
bst_t *bst_join_left(bst_t *a, bst_t *b){
	if (b == NULL) return a;
	b = bst_partition(b, 0);
	b->l = a;
	return b;
}

bst_t *bst_join_left_rand(bst_t *a, bst_t *b){
	if (a == NULL) return b;
	if (b == NULL) return a;
	if (rand() / (RAND_MAX / (a->n + b->n) + 1) < a->n){
		a->r = bst_join_left_rand(a->r, b);
		return a;
	}
	b->l = bst_join_left_rand(a, b->l);
	return b;
}

bst_t *bst_delete2(bst_t *t, int x){
	if (t == NULL) 
		return NULL;

	if (x < t->e)
		t->l = bst_delete2(t->l, x);
	else if (x > t->e)
		t->r = bst_delete2(t->r, x);
	else {
		bst_t *tmp = t;
		t = bst_join_left(t->l, t->r);
		free(tmp);
	}
	fix_n(t);
	return t;
}

bst_t *bst_delete_rand(bst_t *t, int x){
	if (t == NULL) 
		return NULL;

	if (x < t->e)
		t->l = bst_delete2(t->l, x);
	else if (x > t->e)
		t->r = bst_delete2(t->r, x);
	else {
		bst_t *tmp = t;
		t = bst_join_left_rand(t->l, t->r);
		free(tmp);
	}
	fix_n(t);
	return t;
}

bst_t *bst_join(bst_t *a, bst_t *b){
	if (b == NULL) return a;
	if (a == NULL) return b;

	b = bst_insert_root(b, a->e);
	b->l = bst_join(a->l, b->l);
	b->r = bst_join(a->r, b->r);

	fix_n(b);
	free(a);

	return b;
}

void bst_inorder(bst_t *t, void (*visit)(bst_t *)){
	if (!t) return;
	bst_inorder(t->l, visit);
	visit(t);
	bst_inorder(t->r, visit);
}

static void bst_print_node(int x, int h){
	int i;
	for (i = 0; i < h; i++) printf("    ");
	printf("%4c\n", x);
}

static void bst_print_re(bst_t *t, int h){
	if (!t) {
		bst_print_node('-', h);
		return;
	}
	bst_print_re(t->r, h + 1);
	bst_print_node(t->e, h);
	bst_print_re(t->l, h + 1);
}

void bst_print(bst_t *t){
	bst_print_re(t, 0);
}


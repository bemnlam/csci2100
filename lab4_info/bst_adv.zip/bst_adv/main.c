#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "bst.h"

void visit(bst_t *t){
	printf("%c", t->e);
}

void test_basic(void){
	bst_t *t = NULL; // empty tree
	//char s[] = "ASERCHI";
	char s[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int i, n = 26;

	//srand(time(NULL));

	for (i = 0; i < n; i++)
		t = bst_insert_rand(t, s[i]);

	//t = bst_partition(t, 2);

	bst_print(t);
	printf("---------------------\n");
	bst_inorder(t, visit);

	//t = bst_delete2(t, 'E');
	t = bst_balance(t);

	bst_print(t);
	printf("---------------------\n");
	bst_inorder(t, visit);

	bst_make_empty(t);
}

void test_join(void){
	bst_t *t1 = NULL, *t2 = NULL;
	char s1[] = "ASERCHI";
	char s2[] = "BDFGJKM";
	int i, n = 7;
	for (i = 0; i < n; i++){
		t1 = bst_insert_rand(t1, s1[i]);
		t2 = bst_insert_rand(t2, s2[i]);
	}
	bst_print(t1);
	bst_inorder(t1, visit);
	printf("\n---------------------\n");
	bst_print(t2);
	bst_inorder(t2, visit);
	printf("\n---------------------\n");

	t2 = bst_join(t1, t2);
	bst_print(t2);
	bst_inorder(t2, visit);
	printf("\n---------------------\n");

	t2 = bst_balance(t2);
	bst_print(t2);
	bst_inorder(t2, visit);
	printf("\n---------------------\n");
}

int main(void){
	test_basic();
	test_join();

	return 0;
}

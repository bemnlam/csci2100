typedef struct bst_s bst_t;
struct bst_s {
	int e;
	int n;
	bst_t *l;
	bst_t *r;
};

bst_t *bst_make_empty(bst_t *t);
bst_t *bst_find(bst_t *t, int x);
bst_t *bst_find_min(bst_t *t);
bst_t *bst_find_max(bst_t *t);
bst_t *bst_insert(bst_t *t, int x);
bst_t *bst_insert_root(bst_t *t, int x);
bst_t *bst_insert_rand(bst_t *t, int x);
bst_t *bst_delete(bst_t *t, int x);
bst_t *bst_delete2(bst_t *t, int x);
bst_t *bst_delete_rand(bst_t *t, int x);
bst_t *bst_partition(bst_t *t, int k);
bst_t *bst_balance(bst_t *t);
bst_t *bst_join(bst_t *a, bst_t *b);
void bst_inorder(bst_t *t, void (*visit)(bst_t *));
void bst_print(bst_t *t);

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include "graph.h"

edge_t new_edge(int, int);

/* global variables for DFS */
static int cnt, *pre;

static void dfs_visit(graph G, edge_t e){
	node *t;
	int w = e.w;
	pre[w] = cnt++;
	printf("pre[%d] = %d\n", w, cnt - 1);
	for (t = G->adj[w]; t != NULL; t = t->next)
		if (pre[t->v] == -1)
			dfs_visit(G, new_edge(w, t->v));
}

void graph_dfs(graph G){
	int i;
	pre = malloc(sizeof(int) * G->V);
	cnt = 0;
	for (i = 0; i < G->V; i++)
		pre[i] = -1;
	
	for (i = 0; i < G->V; i++)
		if (pre[i] == -1)
			dfs_visit(G, new_edge(i, i));

	free(pre);
}

/* Simplified Queue Routines: applicable until to BFS */
static edge_t *queue;
static int nq;
static int *st;

static void queue_init(int V){
	nq = 0;
	queue = malloc(sizeof(edge_t) * V);
}
static void queue_enq(edge_t e){
	queue[nq++] = e;
}
static edge_t queue_deq(void){
	return queue[--nq];
}
static int queue_is_empty(void){
	return (nq == 0);
}
static void queue_free(void){
	free(queue);
}

static void bfs_visit(graph G, edge_t e){
	int w;
	node *t;
	queue_enq(e);
	pre[e.w] = cnt++;
	printf("pre[%d] = %d\n", e.w, cnt - 1);
	while (!queue_is_empty()){
		e = queue_deq();
		w = e.w;
		st[w] = e.v;
		for (t = G->adj[w]; t != NULL; t = t->next){
			if (pre[t->v] == -1){
				queue_enq(new_edge(w, t->v));
				pre[t->v] = cnt++;
				printf("pre[%d] = %d\n", t->v, cnt - 1);
			}
		}
	}
}

void graph_bfs(graph G){
	int i;

	pre = malloc(sizeof(int) * G->V);
	st = malloc(sizeof(int) * G->V);
	cnt = 0;
	for (i = 0; i < G->V; i++){
		pre[i] = -1;
		st[i] = -1;
	}
	queue_init(G->V);

	bfs_visit(G, new_edge(0, 0));

	printf("pre[]=");
	for (i = 0; i < G->V; i++)
		printf(" %d", pre[i]);
	printf("\n st[]=");
	for (i = 0; i < G->V; i++)
		printf(" %d", st[i]);
	printf("\n");

	queue_free();
	free(pre);
	free(st);
}


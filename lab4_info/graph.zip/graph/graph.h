typedef struct {
	int v;
	int w;
} edge_t;

typedef struct graph_t *graph;

typedef struct node_s node;
struct node_s {
	int v;
	int w;
	node *next;
};

struct graph_t {
	int V;
	int E;
	node **adj;
};

/* graph.c OR graph_adj.c */
edge_t new_edge(int, int);
graph graph_init(int);
void graph_insert_e(graph, edge_t, int);
void graph_remove_e(graph, edge_t);
int graph_edges(graph, edge_t []);
graph graph_copy(graph);
void graph_free(graph);
graph graph_rand(int, int);
void graph_show(graph);

/* graph_search.c */
void graph_dfs(graph);
void graph_bfs(graph);

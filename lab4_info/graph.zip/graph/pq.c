#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "pq.h"

// Basic heap utilities
pq_t *pq_init(int max_e){
	pq_t *h = (pq_t *)malloc(sizeof(pq_t));
	h->e = (int *)malloc((max_e + 1) * sizeof(int));
	h->key = (int *)malloc((max_e + 1) * sizeof(int));
	h->index = (int *)malloc((max_e + 1) * sizeof(int));
	h->size = 0;
	h->capacity = max_e;
	h->e[0] = INT_MIN;

	return h;
}

void pq_free(pq_t *h){
	if (!h) return;
	free(h->index);
	free(h->key);
	free(h->e);
	free(h);
}

void pq_make_empty(pq_t *h){
	h->size = 0;
}

int pq_is_empty(pq_t *h){
	return (h->size == 0);
}

int pq_is_full(pq_t *h){
	return (h->size == h->capacity);
}

int pq_find_min(pq_t *h){
	return (h->e[1]);
}

// fix up and down for operations
static void pq_fixup(pq_t *h, int i){
	int parent;
	int e = h->e[i];

	for ( ; i > 0; i = parent){
		parent = i / 2;
		if (parent > 0 && 
			h->key[h->e[i]] < h->key[h->e[parent]]){
			// swap the values
			h->e[i] = h->e[parent];
			h->e[parent] = e;
			h->index[h->e[i]] = i;
			h->index[h->e[parent]] = parent;
		}
		else
			break;
	}
}

static void pq_fixdown(pq_t *h, int i){
	int child;
	int e = h->e[i];

	for ( ; i * 2 <= h->size; i = child){
		// find smaller child
		child = i * 2;
		if (child != h->size && 
			h->key[h->e[child + 1]] < h->key[h->e[child]])
			child++;
		if (h->key[h->e[i]] > h->key[h->e[child]]){
			// swap the values
			h->e[i] = h->e[child];
			h->e[child] = e;
			h->index[h->e[i]] = i;
			h->index[h->e[child]] = child;
		}
		else
			break;
	}
}

pq_t *pq_build_key(int n, int *e, int *key){
	int i;
	pq_t *h = pq_init(n);
	
	// copy the values
	for (i = 0; i < n; i++){
		h->e[i + 1] = e[i];
		h->index[e[i]] = i + 1;
		h->key[h->e[i + 1]] = key[i];
	}
	h->size = n;

	for (i = h->size / 2; i > 0; i--)
		pq_fixdown(h, i);

	return h;
}

void pq_decrease_key(pq_t *h, int v, int new_key){
	int i = h->index[v];

	if (h->key[v] <= new_key)
		return; // do nothing
	h->key[v] = new_key;
	pq_fixup(h, i); // heapify
}

int pq_delete_min(pq_t *h){
	int min_e = h->e[1];

	// duplicate the last element to the first position
	h->e[1] = h->e[h->size--];
	h->index[h->e[1]] = 1;

	pq_fixdown(h, 1); // and heapify again

	h->index[min_e] = -1; // bookkeeping
	return min_e;
}

void pq_print(pq_t *h){
	int i;
	printf("heap size=%d, heap capacity=%d\n", h->size, h->capacity);

	printf("e   : ");
	for (i = 1; i < h->size; i++)
		printf("%2d ", h->e[i]);
	printf("%2d\n", h->e[i]);

	printf("keys: ");
	for (i = 1; i < h->size; i++)
		printf("%2d ", h->key[h->e[i]]);
	printf("%2d\n", h->key[h->e[i]]);

	printf("-------------------\n      ");
	for (i = 0; i < h->capacity; i++)
		printf("%2d ", i);
	putchar('\n');
	printf("idx : ");
	for (i = 0; i < h->capacity - 1; i++)
		printf("%2d ", h->index[i]);
	printf("%2d\n", h->index[i]);
}


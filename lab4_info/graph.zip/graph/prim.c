#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "pq.h"
#include "graph.h"

#define PRIM_INFTY INT_MAX
#define PRIM_NULL INT_MIN
#define VERBOSE

// g: graph to be MST on
// r: arbitrary root vertex
void graph_prim(graph G, int r){
	int i, u, v, cnt = 0, n = G->V;
	int *e = (int *)malloc(n * sizeof(int)); 
	int *p = (int *)malloc(n * sizeof(int)); 
	int *key = (int *)malloc((n + 1) * sizeof(int)); 
	char *pre = (char *)malloc(n * sizeof(char));
	pq_t *pq;
	node *t;

	for (i = 0; i < n; i++){
		key[i] = PRIM_INFTY;
		p[i] = PRIM_NULL;
		e[i] = i;
		pre[i] = -1;
	}
	key[r] = 0;
	pq = pq_build_key(n, e, key);

	while (!pq_is_empty(pq)){
		u = pq_delete_min(pq);
#ifdef VERBOSE
		printf("prim(): extract_min=%d\n", u);
#endif

		pre[u] = cnt++;
		for (t = G->adj[u]; t != NULL; t = t->next){
			v = t->v;
			if (pre[v] == -1 && t->w < key[v]){
				p[v] = u;
				key[v] = t->w;
				pq_decrease_key(pq, v, t->w);
#ifdef VERBOSE
				printf("prim(): decrease_key=(%d, %d, %d)\n", u, v, t->w);
#endif
			}
		}
	}

	// MST is all Es in (v, p[v])
	printf("Prim's Algorithm: the MST is\n");
	for (i = 0; i < n; i++){
		if (i == r) continue; // skip root
		printf("(%d, %d): %d\n", i, p[i], key[i]);
	}
	
	pq_free(pq);
	free(e);
	free(p);
	free(key);
	free(pre);
}

typedef struct pq_s {
	int capacity;
	int size;
	int *e; // the complete binary tree
	int *index; // for heap index lookup
	int *key; // storing keys
} pq_t;

// common heap operations
pq_t *pq_init(int max_e);
void 	pq_free(pq_t *h);
int 	pq_is_empty(pq_t *h);
void 	pq_print(pq_t *h);

// key-based minheap operations
pq_t *pq_build_key(int n, int *e, int *key);
void	pq_decrease_key(pq_t *h, int v, int new_key);
int 	pq_delete_min(pq_t *h);


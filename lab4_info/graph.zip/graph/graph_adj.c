#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>
#include "graph.h"

static node *insert(int v, int w, node *next){
	node *x = malloc(sizeof *x);
	x->v = v;
	x->w = w;
	x->next = next;
	return x;
}

edge_t new_edge(int v, int w){
	edge_t e;
	e.v = v;
	e.w = w;
	return e;
}

graph graph_init(int V){
	int v;
	graph G = malloc(sizeof *G);
	G->V = V;
	G->E = 0;
	G->adj = malloc(V * sizeof(node *));
	for (v = 0; v < V; v++)
		G->adj[v] = NULL;
	return G;
}

void graph_free(graph G){
	int i;
	node *t, *u;
	for (i = 0; i < G->V; i++)
		for (t = G->adj[i]; t != NULL; t = u){
			u = t->next;
			free(t);
		}
	free(G->adj);
}

void graph_insert_e(graph G, edge_t e, int weight){
	int v = e.v, w = e.w;
	node *t;
	if (v == w)
		return;
	for (t = G->adj[v]; t != NULL; t = t->next)
		if (t->v == w)
			return;
	G->adj[v] = insert(w, weight, G->adj[v]);
	G->adj[w] = insert(v, weight, G->adj[w]);
	G->E++;
}

void graph_remove_e(graph G, edge_t e){
	printf("to be implemented\n");
}

int graph_edges(graph G, edge_t a[]){
	int v, E = 0;
	node *t;
	for (v = 0; v < G->V; v++)
		for (t = G->adj[v]; t != NULL; t = t->next)
			if (v < t->v)
				a[E++] = new_edge(v, t->v);
	return E;
}

void graph_show(graph G){
	int i;
	node *t;
	printf("%d vertices, %d edges\n", G->V, G->E);
	for (i = 0; i < G->V; i++){
		printf("%2d:", i);
		for (t = G->adj[i]; t != NULL; t = t->next)
			printf(" %2d(w=%2d)", t->v, t->w);
		printf("\n");
	}
}

static int rand_v(graph G){
	return (int)(G->V * (rand() / (RAND_MAX + 1.0)));
}

graph graph_rand(int V, int E){
	graph G = graph_init(V);
	//srand(time(NULL));
	while (G->E < E)
		graph_insert_e(G, new_edge(rand_v(G), rand_v(G)), 1 + rand_v(G));
	return G;
}

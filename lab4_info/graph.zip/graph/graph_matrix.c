#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>
#include "graph.h"

struct graph_t {
	int V;
	int E;
	int **adj;
};

edge_t EDGE(int v, int w){
	edge_t e;
	e.v = v;
	e.w = w;
	return e;
}

static int **matrix_init(int r, int c, int val){
	int i, j;
	int **t = malloc(r * sizeof(int *));
	for (i = 0; i < r; i++)
		t[i] = malloc(c * sizeof(int));
	for (i = 0; i < r; i++)
		for (j = 0; j < c; j++)
			t[i][j] = val;
	return t;
}

graph graph_init(int V){
	graph G = malloc(sizeof *G);
	G->V = V;
	G->E = 0;
	G->adj = matrix_init(V, V, 0);
	return G;
}

void graph_free(graph G){
	int i;
	for (i = 0; i < G->V; i++)
		free(G->adj[i]);
	free(G->adj);
}

void graph_insert_e(graph G, edge_t e){
	int v = e.v, w = e.w;
	if (G->adj[v][w] == 0)
		G->E++;
	G->adj[v][w] = 1;
	G->adj[w][v] = 1;
}

void graph_remove_e(graph G, edge_t e){
	int v = e.v, w = e.w;
	if (G->adj[v][w] == 1)
		G->E--;
	G->adj[v][w] = 0;
	G->adj[w][v] = 0;
}

int graph_edges(graph G, edge_t a[]){
	int v, w, E = 0;
	for (v = 0; v < G->V; v++)
		for (w = v + 1; w < G->V; w++)
			if (G->adj[v][w] == 1)
				a[E++] = EDGE(v, w);
	return E;
}

void graph_show(graph G){
	int i, j;
	printf("%d vertices, %d edges\n", G->V, G->E);
	for (i = 0; i < G->V; i++){
		printf("%2d:", i);
		for (j = 0; j < G->V; j++)
			if (G->adj[i][j] == 1)
				printf(" %2d", j);
		printf("\n");
	}
}

static int rand_v(graph G){
	return (int)(G->V * (rand() / (RAND_MAX + 1.0)));
}

graph graph_rand(int V, int E){
	graph G = graph_init(V);
	//srand(time(NULL));
	while (G->E < E)
		graph_insert_e(G, EDGE(rand_v(G), rand_v(G)));
	return G;
}


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include "pq.h"
#include "graph.h"

#define SHPATH_INFTY 10000
#define SHPATH_NULL -1

static void init(graph G, int s, int *d, int *p){
	int i;
	for (i = 0; i < G->V; i++){
		d[i] = SHPATH_INFTY;
		p[i] = SHPATH_NULL;
	}
	d[s] = 0;
}

int graph_bellmanford(graph G, int s){
	int i, u, v, w, n = G->V;
	int nc = 0; /* nc: negative cycle */
	node *t;
	int *p = malloc(n * sizeof(int));
	int *d = malloc(n * sizeof(int));

	init(G, s, d, p);

	for (i = 0; i < n - 1; i++)
		for (u = 0; u < n; u++)
			for (t = G->adj[u]; t != NULL; t = t->next){
				v = t->v;
				w = t->w;
				if (d[v] > d[u] + w){
					d[v] = d[u] + w;
					p[v] = u;
				}
			}
	/* detect negative cycle */
	for (u = 0; u < n; u++)
		for (t = G->adj[u]; t != NULL; t = t->next){
			v = t->v;
			w = t->w;
			if (d[v] > d[u] + w)
				nc = 1;
		}

	printf("Bellman-Ford's Algorithm:\n");
	for (i = 0; i < n; i++)
		printf("d[%d] = %d (p=%d)\n", i, d[i], p[i]);

	free(p);
	free(d);

	return !nc;
}

void graph_dijkstra(graph G, int s){
	int i, u, v, w, n = G->V;
	node *t;
	int *p = (int *)malloc(n * sizeof(int));
	int *d = (int *)malloc(n * sizeof(int));
	int *e = (int *)malloc(n * sizeof(int));
	pq_t *pq;

	init(G, s, d, p);

	for (i = 0; i < n; i++)
		e[i] = i;
	pq = pq_build_key(n, e, d);

	while (!pq_is_empty(pq)){
		u = pq_delete_min(pq);

		for (t = G->adj[u]; t != NULL; t = t->next){
			v = t->v;
			w = t->w;
			if (d[v] > d[u] + w){
				d[v] = d[u] + w;
				p[v] = u;
				pq_decrease_key(pq, v, d[v]);
			}
		}
	}

	printf("Dijkstra's Algorithm:\n");
	for (i = 0; i < n; i++)
		printf("d[%d] = %d (p=%d)\n", i, d[i], p[i]);

	free(e);
	free(p);
	free(d);
	pq_free(pq);
}

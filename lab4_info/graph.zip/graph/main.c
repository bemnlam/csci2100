#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

void graph_prim(graph G, int r);
int graph_bellmanford(graph G, int r);
int graph_dijkstra(graph G, int r);

void test_random(int V, int E){
	graph G = graph_rand(V, E);
	graph_show(G);
	graph_dfs(G);
	graph_bfs(G);
	graph_prim(G, 0);
	graph_free(G);
}

void test_random_shpath(int V, int E){
	graph G = graph_rand(V, E);
	graph_show(G);
	if (graph_bellmanford(G, 0) == 0){
		printf("There is a negative cycle\n");
	}
	graph_dijkstra(G, 0);
	graph_free(G);
}

void test(void){
	int n, u, v, w;
	graph G;

	scanf("%d", &n);

	G = graph_init(n);

	while (scanf("%d-%d %d", &u, &v, &w) == 3)
		graph_insert_e(G, new_edge(u, v), w);

	graph_show(G);

	graph_dfs(G);
	graph_bfs(G);
	graph_prim(G, 0);
	graph_bellmanford(G, 0);
	graph_dijkstra(G, 0);

	graph_free(G);
}

int main(int argc, char *argv[]){
	if (argc == 3){
		int V = atoi(argv[1]), E = atoi(argv[2]);
		test_random(V, E);
		//test_random_shpath(V, E);
	}
	else {
		test();
	}

	return 0;
}
	

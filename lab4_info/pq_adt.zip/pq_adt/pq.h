#ifndef __PQ_H_
#define __PQ_H_
typedef struct {
	int k;
	char *s;
} e_t;

typedef struct {
	int n;
	e_t *a;
} pq_t;

typedef int pq_pos_t;

pq_t *	pq_create();
void 	pq_free(pq_t *pq);
int 	pq_is_empty(pq_t *pq);
void 	pq_insert(pq_t *pq, e_t e);
e_t 	pq_delmax(pq_t *pq);
void 	pq_delete(pq_t *pq, pq_pos_t k);
void 	pq_change(pq_t *pq, pq_pos_t k, e_t e);
void	pq_print(pq_t *pq);
void	heapsort(int n, e_t *a);
#endif

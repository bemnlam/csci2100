#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "pq.h"

#define MAX_SIZE 100

pq_t *pq_create(){
	pq_t *pq = malloc(sizeof *pq);
	pq->a = malloc(MAX_SIZE * sizeof(pq_t));
	pq->n = 0;
	return pq;
}

void pq_free(pq_t *pq){
	free(pq->a);
	free(pq);
}

int pq_is_empty(pq_t *pq){
	return (pq->n == 0);
}

void pq_insert(pq_t *pq, e_t e){
	pq->a[pq->n++] = e;
}

e_t pq_delmax(pq_t *pq){
	int i, m = 0;
	e_t max_e = {INT_MIN, NULL};
	if (pq->n == 0) return max_e;

	for (i = 1; i < pq->n; i++)
		if (pq->a[m].k < pq->a[i].k)
			m = i;
	max_e = pq->a[m];
	pq->n--;
	for (i = m; i < pq->n; i++)
		pq->a[i] = pq->a[i + 1];

	return max_e;
}

void heapsort(int n, e_t *a){
	perror("heapsort not available in this implementation\n");
}

void pq_delete(pq_t *pq, pq_pos_t k){
	perror("not yet implemented.\n");
}

void pq_change(pq_t *pq, pq_pos_t k, e_t e){
	perror("not yet implemented.\n");
}

void pq_print(pq_t *pq){
	int i;
	for (i = 1; i <= pq->n; i++)
		printf("%d ", pq->a[i].k);
	printf("n=%d\n", pq->n);
}



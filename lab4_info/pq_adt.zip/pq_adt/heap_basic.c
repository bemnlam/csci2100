#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

/* swap two integers */
static inline void swap(int *a, int *b){ int tmp = *a; *a = *b; *b = tmp; }

void fix_up(int a[], int i){
	for ( ; a[i / 2] >= a[i]; i /= 2)
		swap(&a[i / 2], &a[i]);
}

void fix_down(int a[], int n, int i){
	int j; /* child */

	for ( ; i * 2 <= n; i = j){
		j = i * 2; /* find smaller child */
		if (j < n && a[j + 1] < a[j]) j++;
		if (a[i] <= a[j])
			break;
		/* swap the values */
		swap(&a[i], &a[j]);
	}
}

void heapify(int a[], int n){
	int i;
	for (i = n / 2; i > 0; i--)
		fix_down(a, n, i);
}

#define PRINT for (i = 1; i <= n; i++) printf("%d ", a[i]); printf("\n")
#define N 20

int main(void){
	int i, a[N] = {INT_MIN, 1, 2, 3, 4, 5, 6, 7, 8}, n = 8;
	for (i = 1; i <= n; i++) /* random shuffle */
		swap(a + rand() % n, a + rand() % n);

	PRINT;
	heapify(a, n);
	PRINT;

	/* insert demo */
	a[++n] = 9;
	fix_up(a, n);
	a[++n] = 0;
	fix_up(a, n);
	PRINT;

	/* delmin demo */
	printf("min=%d\n", a[1]);
	swap(&a[1], &a[n]);
	fix_down(a, --n, 1);

	/* heapsort demo */
	for (i = n; i > 1; i--){
		swap(&a[1], &a[i]);
		fix_down(a, i - 1, 1);
	}
	PRINT;

	return 0;
}


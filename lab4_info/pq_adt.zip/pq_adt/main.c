#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "pq.h"

#define N 20

int main(void){
	int i;
	e_t a[N + 1];
	pq_t *pq;

	a[0].k = INT_MAX;
	for (i = 1; i <= N; i++)
		a[i].k = i;
	for (i = 0; i < N; i++){
		int x = rand() % N + 1;
		int y = rand() % N + 1;
		if (x == y) continue;
		e_t e = a[x];
		a[x] = a[y];
		a[y] = e;
	}
		
	printf("pq test:\n");
	pq = pq_create();
	for (i = 1; i <= N; i++)
		pq_insert(pq, a[i]);
	pq_print(pq);
	
	//e = pq_delmax(pq);
	//printf("max.e=%d\n", e.k);
	while (!pq_is_empty(pq)){
		printf("%d ", pq_delmax(pq).k);
	}
	putchar('\n');

	pq_free(pq);

	printf("heapsort test:\n");
	heapsort(N, a);
	for (i = 1; i <= N; i++)
		printf("%d ", a[i].k);
	printf("\n");

	return 0;
}
